# NohBoard — Fabric port (Minecraft 1.21.11)

This is an in-progress Java reimplementation of NohBoard 1.2.2 for the Minecraft client.

## Target configuration

- Minecraft: 1.21.11
- Mod loader: Fabric Loader 0.18.1+
- Fabric API: 0.141.1+1.21.11
- Build JDK: 25
- Class-file target: Java 25
- Mod id / display name: `nohboard` / `NohBoard`

JDK 25 is used to run Gradle and compile the sources. The produced classes target Java 25 bytecode, so the Minecraft runtime must support Java 25.

## Current implementation

- HUD overlay registered through Fabric's HUD element API.
- Loads original NohBoard `keyboard.json` layout files from bundled resources.
- Original keyboard resource tree (layouts, styles, and image assets) copied from NohBoard 1.2.2.
- Draws keyboard and mouse-key rectangles using their original boundaries and text positions.
- Reads keyboard state through GLFW; includes common Windows virtual-key to GLFW mappings and left/right modifier handling.
- Reads left/right/middle and X1/X2 mouse buttons.
- Captures vertical and horizontal mouse-wheel events through a client mixin and highlights the matching `MouseScroll` element briefly.
- Initial mouse-speed indicator visualization.
- F7 opens the in-game settings screen; F8 toggles the overlay.
- Settings screen can toggle overlay, cycle scale, change among several included layouts, move the overlay, toggle the panel background, and reset placement.
- Settings persist to `.minecraft/config/nohboard.json`.
- Colors, text color, scale, position, layout and panel visibility can also be edited in the config JSON.

## Known limitations / not yet full parity

This is not yet a complete feature-for-feature port of the original Windows application.

- The full original drag-and-drop layout editor and per-element property dialogs are not implemented.
- Original `.style` files and image-backed pressed/unpressed states are bundled but not yet fully interpreted by the renderer; the renderer currently uses configurable flat colors.
- Only a curated list of layouts is selectable in the in-game menu, although the original layout files are bundled.
- Input capture is limited to input delivered to the Minecraft client window. It cannot reproduce Windows global hooks while Minecraft is unfocused.
- Mouse-speed indicator rendering is an initial approximation.
- Scroll direction capture and mixin target must be verified against the exact 1.21.11 mappings by compiling and running in-game.
- No successful Gradle build has been recorded in the environment used to prepare this source archive.

## Build

Use JDK 25 and Gradle 9.2+:

```bash
gradle build --no-daemon
```

The output JAR should be in `build/libs/`. Do not use a `-sources.jar` file as the mod.

## Controls

- `F7`: open NohBoard settings.
- `F8`: toggle the overlay.

## License and attribution

The original NohBoard code and bundled resources are licensed under GPL-2.0. See `LICENSE-NohBoard-GPL-2.0.txt`. This Java project is a reimplementation and is not a conversion of the original Windows executable.


## Build requirements (updated)

- JDK 25
- Gradle 9.2 or newer (Fabric Loom 1.14 requires Gradle 9.2)
- Internet access to Fabric Maven, Gradle Plugin Portal, Maven Central, and Minecraft libraries

Build command: `gradle build`

The resulting remapped mod should be in `build/libs/` (choose the jar without `-sources`).

Important: this source tree is a work in progress, not a verified full port. The in-game editor, complete style interpreter, and profile manager are not yet implemented. A successful build and in-game test have not been completed.
