package com.nohboard.mixin;

import com.nohboard.NohBoardClient;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Captures wheel movement delivered to the Minecraft client window. */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Inject(method = "onScroll", at = @At("HEAD"))
    private void nohboard$captureScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        NohBoardClient.recordScroll(horizontal, vertical);
    }
}
