package com.nohboard;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Persistent client-side settings for NohBoard. */
public final class NohBoardConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = Minecraft.getInstance().gameDirectory.toPath().resolve("config/nohboard.json");

    public boolean enabled = true;
    public boolean showPanel = true;
    public float scale = 0.52f;
    public int x = 12;
    public int y = 12;
    public String layout = "Normal/us_intl_basicmouse/keyboard.json";
    public int activeColor = 0xFF54D68A;
    public int inactiveColor = 0xCC252B33;
    public int borderColor = 0xFF697482;
    public int textColor = 0xFFFFFFFF;

    public static NohBoardConfig load() {
        try {
            Files.createDirectories(FILE.getParent());
            if (Files.exists(FILE)) {
                try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
                    NohBoardConfig config = GSON.fromJson(reader, NohBoardConfig.class);
                    if (config != null) {
                        config.scale = Math.max(0.15f, Math.min(1.5f, config.scale));
                        if (config.layout == null || config.layout.isBlank()) config.layout = "Normal/us_intl_basicmouse/keyboard.json";
                        return config;
                    }
                }
            }
        } catch (Exception exception) {
            System.err.println("[NohBoard] Could not read config: " + exception.getMessage());
        }
        return new NohBoardConfig();
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (Exception exception) {
            System.err.println("[NohBoard] Could not save config: " + exception.getMessage());
        }
    }
}
