package com.nohboard;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Small in-game settings screen; advanced settings remain editable in config/nohboard.json. */
public final class NohBoardScreen extends Screen {
    public NohBoardScreen() {
        super(Component.literal("NohBoard settings"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 105;
        int top = this.height / 2 - 78;
        addRenderableWidget(Button.builder(toggleLabel(), button -> {
            NohBoardClient.toggleOverlay();
            button.setMessage(toggleLabel());
        }).bounds(left, top, 210, 20).build());
        addRenderableWidget(Button.builder(scaleLabel(), button -> {
            NohBoardClient.cycleScale();
            button.setMessage(scaleLabel());
        }).bounds(left, top + 25, 210, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Next keyboard layout"), button -> NohBoardClient.nextLayout())
                .bounds(left, top + 50, 210, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Move overlay left"), button -> NohBoardClient.moveOverlay(-10, 0))
                .bounds(left, top + 75, 102, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Move overlay right"), button -> NohBoardClient.moveOverlay(10, 0))
                .bounds(left + 108, top + 75, 102, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Move overlay up"), button -> NohBoardClient.moveOverlay(0, -10))
                .bounds(left, top + 100, 102, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Move overlay down"), button -> NohBoardClient.moveOverlay(0, 10))
                .bounds(left + 108, top + 100, 102, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Panel background: " + (NohBoardClient.isPanelVisible() ? "ON" : "OFF")), button -> {
            NohBoardClient.togglePanel();
            button.setMessage(Component.literal("Panel background: " + (NohBoardClient.isPanelVisible() ? "ON" : "OFF")));
        }).bounds(left, top + 125, 210, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset position and scale"), button -> NohBoardClient.resetPlacement())
                .bounds(left, top + 150, 210, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), button -> onClose())
                .bounds(left, top + 175, 210, 20).build());
    }

    private Component toggleLabel() {
        return Component.literal("Overlay: " + (NohBoardClient.isEnabled() ? "ON" : "OFF"));
    }

    private Component scaleLabel() {
        return Component.literal("Scale: " + String.format(java.util.Locale.ROOT, "%.2f", NohBoardClient.getScale()));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(font, title, width / 2, height / 2 - 130, 0xFFFFFFFF);
        graphics.drawCenteredString(font, "F7 opens this menu · F8 toggles the overlay", width / 2, height / 2 + 115, 0xFFCCCCCC);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
