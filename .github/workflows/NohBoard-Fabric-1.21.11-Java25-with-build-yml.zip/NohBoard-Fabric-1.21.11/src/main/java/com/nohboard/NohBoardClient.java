package com.nohboard;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * NohBoard Fabric port. The original layout JSON format is retained where possible.
 * Original NohBoard is Copyright (C) Eric Bataille and contributors, GPL-2.0.
 */
public final class NohBoardClient implements ClientModInitializer {
    private static final String DEFAULT_LAYOUT = "Normal/us_intl_basicmouse/keyboard.json";
    private static final int PANEL = 0x990D1117;
    private static final String[] LAYOUTS = {
        "Normal/us_intl_basicmouse/keyboard.json",
        "Normal/us_intl_basic/keyboard.json",
        "Normal/us_intl/keyboard.json",
        "Normal/azerty_basic/keyboard.json",
        "Normal/de_basic/keyboard.json",
        "Normal/scandi_basic/keyboard.json",
        "Normal/mouseAll/keyboard.json"
    };
    private static JsonObject layout;
    private static NohBoardConfig config;
    private static boolean f7WasDown;
    private static boolean f8WasDown;
    private static int layoutIndex;
    private static int scrollCode = -1;
    private static int scrollTicks;
    private static double lastMouseX;
    private static double lastMouseY;
    private static double mouseDx;
    private static double mouseDy;
    private static boolean haveMouse;

    @Override
    public void onInitializeClient() {
        config = NohBoardConfig.load();
        layout = loadLayout(config.layout);
        for (int i = 0; i < LAYOUTS.length; i++) if (LAYOUTS[i].equals(config.layout)) layoutIndex = i;
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.getWindow() == null) return;
            boolean f7 = GLFW.glfwGetKey(mc.getWindow().handle(), GLFW.GLFW_KEY_F7) == GLFW.GLFW_PRESS;
            boolean f8 = GLFW.glfwGetKey(mc.getWindow().handle(), GLFW.GLFW_KEY_F8) == GLFW.GLFW_PRESS;
            if (f7 && !f7WasDown && mc.screen == null) mc.setScreen(new NohBoardScreen());
            if (f8 && !f8WasDown) toggleOverlay();
            f7WasDown = f7;
            f8WasDown = f8;
            if (scrollTicks > 0) scrollTicks--;
            else scrollCode = -1;
        });
        HudElementRegistry.addLast(
            Identifier.fromNamespaceAndPath("nohboard", "input_overlay"),
            NohBoardClient::render
        );
    }

    private static JsonObject loadLayout(String path) {
        String resource = "/assets/nohboard/layouts/" + path;
        try (InputStream stream = NohBoardClient.class.getResourceAsStream(resource)) {
            if (stream == null) return null;
            JsonReader reader = new JsonReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
            reader.setLenient(true); // Some original NohBoard layouts contain trailing commas.
            return JsonParser.parseReader(reader).getAsJsonObject();
        } catch (Exception exception) {
            System.err.println("[NohBoard] Could not load layout " + path + ": " + exception.getMessage());
            return null;
        }
    }

    private static void render(GuiGraphics graphics, net.minecraft.client.DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        if (!config.enabled || mc.options.hideGui || mc.getWindow() == null) return;
        if (layout == null) {
            renderFallback(graphics, mc);
            return;
        }

        int sourceWidth = number(layout, "Width", 1024);
        int sourceHeight = number(layout, "Height", 328);
        float scale = Math.min(config.scale, Math.min((mc.getWindow().getGuiScaledWidth() - 12f) / sourceWidth,
                (mc.getWindow().getGuiScaledHeight() - 12f) / sourceHeight));
        scale = Math.max(0.12f, scale);
        int originX = config.x;
        int originY = config.y;
        int width = Math.round(sourceWidth * scale);
        int height = Math.round(sourceHeight * scale);
        if (config.showPanel) graphics.fill(originX - 5, originY - 5, originX + width + 5, originY + height + 5, PANEL);

        JsonArray elements = layout.has("Elements") && layout.get("Elements").isJsonArray()
                ? layout.getAsJsonArray("Elements") : new JsonArray();
        for (JsonElement element : elements) {
            if (!element.isJsonObject()) continue;
            JsonObject item = element.getAsJsonObject();
            String type = string(item, "__type", "KeyboardKey");
            if ("MouseSpeedIndicator".equals(type)) {
                drawMouseSpeed(graphics, item, originX, originY, scale);
                continue;
            }
            int[] bounds = bounds(item, originX, originY, scale);
            if (bounds == null) continue;
            boolean pressed = isPressed(item, type, mc);
            int fill = pressed ? config.activeColor : config.inactiveColor;
            graphics.fill(bounds[0], bounds[1], bounds[2], bounds[3], fill);
            graphics.fill(bounds[0], bounds[1], bounds[2], bounds[1] + 1, config.borderColor);
            graphics.fill(bounds[0], bounds[3] - 1, bounds[2], bounds[3], config.borderColor);
            graphics.fill(bounds[0], bounds[1], bounds[0] + 1, bounds[3], config.borderColor);
            graphics.fill(bounds[2] - 1, bounds[1], bounds[2], bounds[3], config.borderColor);

            String label = string(item, "Text", "");
            if ("KeyboardKey".equals(type) && isShiftDown(mc) && item.has("ShiftText")) {
                label = string(item, "ShiftText", label);
            }
            if (label.isEmpty()) continue;
            JsonObject pos = object(item, "TextPosition");
            int tx = pos == null ? (bounds[0] + bounds[2]) / 2 : originX + Math.round(number(pos, "X", 0) * scale);
            int ty = pos == null ? (bounds[1] + bounds[3]) / 2 : originY + Math.round(number(pos, "Y", 0) * scale);
            int tw = mc.font.width(label);
            int th = 8;
            graphics.drawString(mc.font, label, tx - tw / 2, ty - th / 2, config.textColor, true);
        }
    }

    private static boolean isPressed(JsonObject item, String type, Minecraft mc) {
        JsonArray codes = item.has("KeyCodes") && item.get("KeyCodes").isJsonArray()
                ? item.getAsJsonArray("KeyCodes") : new JsonArray();
        for (JsonElement codeElement : codes) {
            if (!codeElement.isJsonPrimitive() || !codeElement.getAsJsonPrimitive().isNumber()) continue;
            int code = codeElement.getAsInt();
            if ("MouseScroll".equals(type)) {
                if (scrollTicks > 0 && code == scrollCode) return true;
            } else if ("MouseKey".equals(type)) {
                int button = switch (code) {
                    case 0 -> GLFW.GLFW_MOUSE_BUTTON_LEFT;
                    case 1 -> GLFW.GLFW_MOUSE_BUTTON_RIGHT;
                    case 2 -> GLFW.GLFW_MOUSE_BUTTON_MIDDLE;
                    case 3 -> GLFW.GLFW_MOUSE_BUTTON_4;
                    case 4 -> GLFW.GLFW_MOUSE_BUTTON_5;
                    default -> -1;
                };
                if (button >= 0 && GLFW.glfwGetMouseButton(mc.getWindow().handle(), button) == GLFW.GLFW_PRESS) return true;
            } else if ("KeyboardKey".equals(type)) {
                if (isKeyboardCodeDown(mc, code)) return true;
            }
        }
        return false;
    }

    private static boolean isShiftDown(Minecraft mc) {
        long window = mc.getWindow().handle();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }

    private static boolean isKeyboardCodeDown(Minecraft mc, int code) {
        long window = mc.getWindow().handle();
        if (code == 16 || code == 160 || code == 161) {
            return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                    || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        }
        if (code == 17 || code == 162 || code == 163) {
            return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                    || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
        }
        if (code == 18 || code == 164 || code == 165) {
            return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS
                    || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
        }
        int glfw = winKeyToGlfw(code);
        return glfw >= 0 && InputConstants.isKeyDown(mc.getWindow(), glfw);
    }

    // Original layouts store Windows virtual-key values; convert common keys to GLFW key values.
    private static int winKeyToGlfw(int key) {
        if (key >= 0x41 && key <= 0x5A) return GLFW.GLFW_KEY_A + (key - 0x41);
        if (key >= 0x30 && key <= 0x39) return GLFW.GLFW_KEY_0 + (key - 0x30);
        if (key >= 0x70 && key <= 0x87) return GLFW.GLFW_KEY_F1 + (key - 0x70);
        return switch (key) {
            case 8 -> GLFW.GLFW_KEY_BACKSPACE;
            case 9 -> GLFW.GLFW_KEY_TAB;
            case 13 -> GLFW.GLFW_KEY_ENTER;
            case 16, 160 -> GLFW.GLFW_KEY_LEFT_SHIFT;
            case 17, 162 -> GLFW.GLFW_KEY_LEFT_CONTROL;
            case 18, 164 -> GLFW.GLFW_KEY_LEFT_ALT;
            case 19 -> GLFW.GLFW_KEY_PAUSE;
            case 20 -> GLFW.GLFW_KEY_CAPS_LOCK;
            case 27 -> GLFW.GLFW_KEY_ESCAPE;
            case 32 -> GLFW.GLFW_KEY_SPACE;
            case 33 -> GLFW.GLFW_KEY_PAGE_UP;
            case 34 -> GLFW.GLFW_KEY_PAGE_DOWN;
            case 35 -> GLFW.GLFW_KEY_END;
            case 36 -> GLFW.GLFW_KEY_HOME;
            case 37 -> GLFW.GLFW_KEY_LEFT;
            case 38 -> GLFW.GLFW_KEY_UP;
            case 39 -> GLFW.GLFW_KEY_RIGHT;
            case 40 -> GLFW.GLFW_KEY_DOWN;
            case 45 -> GLFW.GLFW_KEY_INSERT;
            case 46 -> GLFW.GLFW_KEY_DELETE;
            case 91 -> GLFW.GLFW_KEY_LEFT_SUPER;
            case 92 -> GLFW.GLFW_KEY_RIGHT_SUPER;
            case 96 -> GLFW.GLFW_KEY_KP_0;
            case 97 -> GLFW.GLFW_KEY_KP_1;
            case 98 -> GLFW.GLFW_KEY_KP_2;
            case 99 -> GLFW.GLFW_KEY_KP_3;
            case 100 -> GLFW.GLFW_KEY_KP_4;
            case 101 -> GLFW.GLFW_KEY_KP_5;
            case 102 -> GLFW.GLFW_KEY_KP_6;
            case 103 -> GLFW.GLFW_KEY_KP_7;
            case 104 -> GLFW.GLFW_KEY_KP_8;
            case 105 -> GLFW.GLFW_KEY_KP_9;
            case 106 -> GLFW.GLFW_KEY_KP_MULTIPLY;
            case 107 -> GLFW.GLFW_KEY_KP_ADD;
            case 109 -> GLFW.GLFW_KEY_KP_SUBTRACT;
            case 110 -> GLFW.GLFW_KEY_KP_DECIMAL;
            case 111 -> GLFW.GLFW_KEY_KP_DIVIDE;
            case 144 -> GLFW.GLFW_KEY_NUM_LOCK;
            case 145 -> GLFW.GLFW_KEY_SCROLL_LOCK;
            case 161 -> GLFW.GLFW_KEY_RIGHT_SHIFT;
            case 163 -> GLFW.GLFW_KEY_RIGHT_CONTROL;
            case 165 -> GLFW.GLFW_KEY_RIGHT_ALT;
            case 186 -> GLFW.GLFW_KEY_SEMICOLON;
            case 187 -> GLFW.GLFW_KEY_EQUAL;
            case 188 -> GLFW.GLFW_KEY_COMMA;
            case 189 -> GLFW.GLFW_KEY_MINUS;
            case 190 -> GLFW.GLFW_KEY_PERIOD;
            case 191 -> GLFW.GLFW_KEY_SLASH;
            case 192 -> GLFW.GLFW_KEY_GRAVE_ACCENT;
            case 219 -> GLFW.GLFW_KEY_LEFT_BRACKET;
            case 220 -> GLFW.GLFW_KEY_BACKSLASH;
            case 221 -> GLFW.GLFW_KEY_RIGHT_BRACKET;
            case 222 -> GLFW.GLFW_KEY_APOSTROPHE;
            default -> -1;
        };
    }

    private static int[] bounds(JsonObject item, int ox, int oy, float scale) {
        if (!item.has("Boundaries") || !item.get("Boundaries").isJsonArray()) return null;
        JsonArray points = item.getAsJsonArray("Boundaries");
        if (points.size() < 2) return null;
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        for (JsonElement point : points) {
            if (!point.isJsonObject()) continue;
            JsonObject p = point.getAsJsonObject();
            int x = number(p, "X", 0), y = number(p, "Y", 0);
            minX = Math.min(minX, x); minY = Math.min(minY, y);
            maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
        }
        if (minX == Integer.MAX_VALUE) return null;
        return new int[]{ox + Math.round(minX * scale), oy + Math.round(minY * scale),
                ox + Math.round(maxX * scale), oy + Math.round(maxY * scale)};
    }

    private static void drawMouseSpeed(GuiGraphics g, JsonObject item, int ox, int oy, float scale) {
        JsonObject location = object(item, "Location");
        if (location == null) return;
        int cx = ox + Math.round(number(location, "X", 0) * scale);
        int cy = oy + Math.round(number(location, "Y", 0) * scale);
        int radius = Math.max(3, Math.round(number(item, "Radius", 20) * scale));
        g.fill(cx - radius, cy - radius, cx + radius, cy + radius, 0x886A7480);
        g.fill(cx - 2, cy - 2, cx + 2, cy + 2, 0xFFFFFFFF);
        Minecraft mc = Minecraft.getInstance();
        double[] x = new double[1], y = new double[1];
        GLFW.glfwGetCursorPos(mc.getWindow().handle(), x, y);
        if (haveMouse) { mouseDx = x[0] - lastMouseX; mouseDy = y[0] - lastMouseY; }
        lastMouseX = x[0]; lastMouseY = y[0]; haveMouse = true;
        double length = Math.sqrt(mouseDx * mouseDx + mouseDy * mouseDy);
        if (length > 0.5) {
            int ex = cx + (int) (mouseDx / length * radius);
            int ey = cy + (int) (mouseDy / length * radius);
            g.fill(Math.min(cx, ex), Math.min(cy, ey), Math.max(cx, ex) + 2, Math.max(cy, ey) + 2, 0xFFFFD166);
        }
    }

    private static void renderFallback(GuiGraphics g, Minecraft mc) {
        int x = config.x, y = config.y, w = 28, h = 24, gap = 3;
        if (config.showPanel) g.fill(x - 6, y - 6, x + 3 * w + 2 * gap + 6, y + 3 * h + 2 * gap + 6, PANEL);
        drawFallbackKey(g, mc, "W", x + w + gap, y, w, h, GLFW.GLFW_KEY_W);
        drawFallbackKey(g, mc, "A", x, y + h + gap, w, h, GLFW.GLFW_KEY_A);
        drawFallbackKey(g, mc, "S", x + w + gap, y + h + gap, w, h, GLFW.GLFW_KEY_S);
        drawFallbackKey(g, mc, "D", x + 2 * (w + gap), y + h + gap, w, h, GLFW.GLFW_KEY_D);
        drawFallbackKey(g, mc, "SPACE", x, y + 2 * (h + gap), 3 * w + 2 * gap, h, GLFW.GLFW_KEY_SPACE);
    }

    private static void drawFallbackKey(GuiGraphics g, Minecraft mc, String label, int x, int y, int w, int h, int key) {
        boolean down = InputConstants.isKeyDown(mc.getWindow(), key);
        g.fill(x, y, x + w, y + h, down ? config.activeColor : config.inactiveColor);
        g.drawString(mc.font, label, x + (w - mc.font.width(label)) / 2, y + (h - 8) / 2, config.textColor, true);
    }

    public static void recordScroll(double horizontal, double vertical) {
        if (Math.abs(vertical) >= Math.abs(horizontal)) scrollCode = vertical >= 0 ? 0 : 1;
        else scrollCode = horizontal >= 0 ? 2 : 3;
        scrollTicks = 8;
    }

    public static boolean isEnabled() { return config != null && config.enabled; }
    public static float getScale() { return config == null ? 0.52f : config.scale; }
    public static void toggleOverlay() { if (config == null) return; config.enabled = !config.enabled; config.save(); }
    public static void cycleScale() { if (config == null) return; config.scale += 0.10f; if (config.scale > 1.00f) config.scale = 0.30f; config.save(); }
    public static void resetPlacement() { if (config == null) return; config.x = 12; config.y = 12; config.scale = 0.52f; config.save(); }
    public static void moveOverlay(int dx, int dy) { if (config == null) return; config.x = Math.max(0, config.x + dx); config.y = Math.max(0, config.y + dy); config.save(); }
    public static void togglePanel() { if (config == null) return; config.showPanel = !config.showPanel; config.save(); }
    public static boolean isPanelVisible() { return config != null && config.showPanel; }
    public static void nextLayout() {
        if (config == null) return;
        layoutIndex = (layoutIndex + 1) % LAYOUTS.length;
        config.layout = LAYOUTS[layoutIndex];
        layout = loadLayout(config.layout);
        config.save();
    }

    private static int number(JsonObject object, String name, int fallback) {
        try { return object.has(name) ? object.get(name).getAsInt() : fallback; }
        catch (Exception ignored) { return fallback; }
    }
    private static String string(JsonObject object, String name, String fallback) {
        try { return object.has(name) ? object.get(name).getAsString() : fallback; }
        catch (Exception ignored) { return fallback; }
    }
    private static JsonObject object(JsonObject object, String name) {
        try { return object.has(name) && object.get(name).isJsonObject() ? object.getAsJsonObject(name) : null; }
        catch (Exception ignored) { return null; }
    }
}
