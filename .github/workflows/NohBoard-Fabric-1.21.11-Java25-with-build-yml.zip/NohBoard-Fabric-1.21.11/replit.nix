{ pkgs }: {
  deps = [
    pkgs.jdk25
    pkgs.gradle
    pkgs.unzip
  ];
}
